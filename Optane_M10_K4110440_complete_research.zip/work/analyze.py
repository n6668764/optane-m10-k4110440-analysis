import struct, pathlib, hashlib, json, math, collections, re, datetime
from cryptography.hazmat.primitives.serialization import pkcs7
P=pathlib.Path(__file__).resolve().parent
O=P.parent/'outputs'; O.mkdir(exist_ok=True)
B=(P/'SB_K4110440_x64.dll').read_bytes()
def u16(o): return struct.unpack_from('<H',B,o)[0]
def u32(o): return struct.unpack_from('<I',B,o)[0]
def u64(o): return struct.unpack_from('<Q',B,o)[0]
def entropy(b):
    if not b:return 0
    return -sum((n/len(b))*math.log2(n/len(b)) for n in collections.Counter(b).values())
def hashes(b):return {a:hashlib.new(a,b).hexdigest() for a in ('md5','sha1','sha256','sha512')}
def cstr(o):return B[o:B.find(b'\0',o)].decode('ascii','replace')
assert B[:2]==b'MZ'
pe=u32(0x3c); assert B[pe:pe+4]==b'PE\0\0'
co=pe+4; opt=co+20; magic=u16(opt); is64=magic==0x20b
ns=u16(co+2); osz=u16(co+16); st=opt+osz
sections=[]
for i in range(ns):
    o=st+40*i
    name=B[o:o+8].rstrip(b'\0').decode('ascii','replace')
    vs,va,rs,rp=struct.unpack_from('<IIII',B,o+8)
    sections.append(dict(name=name,virtual_size=vs,rva=va,raw_size=rs,offset=rp,characteristics=hex(u32(o+36)),entropy=entropy(B[rp:rp+rs]),sha256=hashes(B[rp:rp+rs])['sha256']))
def off(rva):
    if rva<u32(opt+60):return rva
    for s in sections:
        if s['rva']<=rva<s['rva']+max(s['virtual_size'],s['raw_size']):return s['offset']+rva-s['rva']
    raise ValueError(f'unmapped RVA {rva:x}')
def loc(o):
    for s in sections:
        if s['offset']<=o<s['offset']+s['raw_size']:return s['name']
    return 'headers/overlay'
nd=u32(opt+(108 if is64 else 92)); dt=opt+(112 if is64 else 96)
dn=['EXPORT','IMPORT','RESOURCE','EXCEPTION','SECURITY','BASERELOC','DEBUG','ARCHITECTURE','GLOBALPTR','TLS','LOAD_CONFIG','BOUND_IMPORT','IAT','DELAY_IMPORT','CLR','RESERVED']
dirs={dn[i]:dict(address=u32(dt+i*8),size=u32(dt+i*8+4)) for i in range(min(nd,16))}
report={'file':'SB_K4110440_x64.dll','length':len(B),'hashes':hashes(B),'entropy':entropy(B),'pe':dict(pe_offset=pe,machine=hex(u16(co)),number_of_sections=ns,timestamp_raw=u32(co+4),timestamp_utc=datetime.datetime.fromtimestamp(u32(co+4),datetime.timezone.utc).isoformat(),characteristics=hex(u16(co+18)),optional_magic=hex(magic),image_base=hex(u64(opt+24) if is64 else u32(opt+28)),entry_rva=hex(u32(opt+16)),linker_version=f'{B[opt+2]}.{B[opt+3]}',size_of_image=u32(opt+56),size_of_headers=u32(opt+60),section_alignment=u32(opt+32),file_alignment=u32(opt+36),checksum=hex(u32(opt+64)),subsystem=u16(opt+68),dll_characteristics=hex(u16(opt+70))), 'directories':dirs,'sections':sections}
imports=[]
if dirs['IMPORT']['address']:
    o=off(dirs['IMPORT']['address'])
    while any(B[o:o+20]):
        oft,ts,fc,n,ft=struct.unpack_from('<IIIII',B,o); names=[]; t=off(oft or ft); stride=8 if is64 else 4
        for i in range(10000):
            v=u64(t+i*stride) if is64 else u32(t+i*stride)
            if not v:break
            names.append({'ordinal':v&0xffff} if v>>(stride*8-1) else {'name':cstr(off(v)+2),'hint':u16(off(v)),'iat_rva':hex(ft+i*stride)})
        imports.append(dict(dll=cstr(off(n)),functions=names));o+=20
report['imports']=imports
exports=[]
if dirs['EXPORT']['address']:
    e=off(dirs['EXPORT']['address']);base,nf,nn,af,an,ao=struct.unpack_from('<IIIIII',B,e+16)
    named={u16(off(ao)+2*i):cstr(off(u32(off(an)+4*i))) for i in range(nn)}
    for i in range(nf):
        r=u32(off(af)+4*i)
        if r: exports.append(dict(ordinal=base+i,name=named.get(i),rva=hex(r),offset=off(r),forwarder=cstr(off(r)) if dirs['EXPORT']['address']<=r<dirs['EXPORT']['address']+dirs['EXPORT']['size'] else None))
    report['export_dll_name']=cstr(off(u32(e+12)))
report['exports']=exports
resources=[]
types={1:'CURSOR',2:'BITMAP',3:'ICON',4:'MENU',5:'DIALOG',6:'STRING',9:'ACCELERATOR',10:'RCDATA',11:'MESSAGETABLE',12:'GROUP_CURSOR',14:'GROUP_ICON',16:'VERSION',24:'MANIFEST'}
if dirs['RESOURCE']['address']:
    ro=off(dirs['RESOURCE']['address'])
    def walk(rel,path,depth=0):
        if depth>8:raise ValueError('resource recursion')
        d=ro+rel; n=u16(d+12)+u16(d+14)
        for i in range(n):
            name,child=struct.unpack_from('<II',B,d+16+i*8)
            if name&0x80000000:
                no=ro+(name&0x7fffffff);k=B[no+2:no+2+2*u16(no)].decode('utf-16le','replace')
            else:k=name
            path2=path+[k]
            if child&0x80000000:walk(child&0x7fffffff,path2,depth+1)
            else:
                de=ro+child;rv,sz,cp,res=struct.unpack_from('<IIII',B,de);fo=off(rv);data=B[fo:fo+sz]
                assert len(data)==sz
                typ=types.get(path2[0],str(path2[0]));fn='resource_'+('_'.join(str(x) for x in path2))+'.bin'
                (O/fn).write_bytes(data)
                resources.append(dict(path=path2,type=typ,rva=hex(rv),offset=fo,size=sz,codepage=cp,entropy=entropy(data),hashes=hashes(data),first_64_hex=data[:64].hex(' '),extracted_file=fn))
    walk(0,[])
report['resources']=resources
strings=[]
for encoding,pattern in [('ascii',rb'[\x20-\x7e]{4,}'),('utf16le',rb'(?:[\x20-\x7e]\x00){4,}')]:
    for m in re.finditer(pattern,B):strings.append(dict(offset=m.start(),section=loc(m.start()),encoding=encoding,text=m.group().decode('utf-16le' if encoding=='utf16le' else 'ascii')))
strings.sort(key=lambda x:x['offset'])
(O/'strings.tsv').write_text('offset_hex\tsection\tencoding\ttext\n'+'\n'.join(f"0x{s['offset']:08X}\t{s['section']}\t{s['encoding']}\t{s['text']}" for s in strings),encoding='utf-8')
report['string_count']=len(strings)
kw=r'AHU|14132|3D.?X|XPoint|PHY|register|firmware|K411|NVMe|Optane|Silicon|SMI|SM22|download|decompress|lzma|zlib|inflate|deflate|signature|RSA|SHA|SB_|protocol|init|boot|Intel|revision|version|\.pdb'
report['interesting_strings']=[s for s in strings if re.search(kw,s['text'],re.I)]
debug=[]
if dirs['DEBUG']['address']:
    d=off(dirs['DEBUG']['address'])
    for i in range(dirs['DEBUG']['size']//28):
        o=d+i*28;typ,sz,rv,ptr=struct.unpack_from('<IIII',B,o+12);blob=B[ptr:ptr+sz];item=dict(type=typ,size=sz,offset=ptr,hex=blob.hex())
        if blob[:4]==b'RSDS':item.update(pdb_path=blob[24:].rstrip(b'\0').decode('utf8','replace'),guid=blob[4:20].hex(),age=struct.unpack_from('<I',blob,20)[0])
        debug.append(item)
report['debug']=debug
certs=[]
sec=dirs['SECURITY'];c=sec['address'];end=c+sec['size']
if c:
    while c+8<=end:
        ln,rev,ty=struct.unpack_from('<IHH',B,c);assert ln>=8 and c+ln<=len(B)
        blob=B[c+8:c+ln];fn=f'authenticode_{len(certs)}.p7b';(O/fn).write_bytes(blob)
        ci=dict(offset=c,length=ln,revision=hex(rev),certificate_type=ty,file=fn)
        try:
            cc=pkcs7.load_der_pkcs7_certificates(blob)
            ci['certificates']=[dict(subject=x.subject.rfc4514_string(),issuer=x.issuer.rfc4514_string(),serial=hex(x.serial_number),not_before=x.not_valid_before_utc.isoformat(),not_after=x.not_valid_after_utc.isoformat(),signature_hash=x.signature_hash_algorithm.name) for x in cc]
        except Exception as ex:ci['parse_error']=str(ex)
        certs.append(ci);c+=(ln+7)&~7
report['certificates']=certs
raw_end=max(s['offset']+s['raw_size'] for s in sections)
report['overlay']=dict(offset=raw_end,size=len(B)-raw_end,entropy=entropy(B[raw_end:]),certificate_offset=sec['address'])
# PE checksum, excluding its own four bytes.
cs=opt+64;total=0
for i in range(0,len(B),2):
    if cs<=i<cs+4:continue
    w=int.from_bytes(B[i:i+2],'little');total+=w;total=(total&0xffff)+(total>>16)
total=(total&0xffff)+(total>>16);total+=len(B)
report['pe']['calculated_checksum']=hex(total)
# Bounded magic scan; candidates are not treated as validated formats.
magics={'MZ':b'MZ','ELF':b'\x7fELF','ZIP':b'PK\x03\x04','GZIP':b'\x1f\x8b\x08','XZ':b'\xfd7zXZ\x00','BZIP2':b'BZh','7ZIP':b'7z\xbc\xaf\x27\x1c','ZSTD':b'\x28\xb5\x2f\xfd','LZ4':b'\x04\x22\x4d\x18','CAB':b'MSCF','Intel_$FPT':b'$FPT','Intel_$MN2':b'$MN2','Intel_$MAN':b'$MAN'}
scan={}
for n,mg in magics.items():
    hits=[m.start() for m in re.finditer(re.escape(mg),B)]
    scan[n]=dict(count=len(hits),offsets=hits[:500])
report['magic_candidates']=scan
blocks=[dict(offset=o,size=len(B[o:o+4096]),section=loc(o),entropy=entropy(B[o:o+4096])) for o in range(0,len(B),4096)]
(O/'entropy_4k.tsv').write_text('offset_hex\tsection\tsize\tentropy\n'+'\n'.join(f"0x{x['offset']:08X}\t{x['section']}\t{x['size']}\t{x['entropy']:.6f}" for x in blocks),encoding='utf8')
(O/'analysis.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k not in ['interesting_strings','magic_candidates']},indent=2))
print('INTERESTING STRINGS:')
for s in report['interesting_strings']:print(f"{s['offset']:08x} {s['section']} {s['text'][:500]}")
print('MAGIC:',json.dumps(scan))

import pathlib,struct,json,hashlib,csv
from continue_static import disasm,CALLS
P=pathlib.Path(__file__).resolve().parent;O=P.parent/'outputs';D=O/'continued_analysis'
B=(O/'firmware_PBUF.bin').read_bytes();F=(O/'K4110440_005_signed_firmware.bin').read_bytes()
maps=[ [7,5,3,1,0,2,4,6,15,13,11,9,8,10,12,14], [0,2,4,6,7,5,3,1,8,10,12,14,15,13,11,9] ]
def permutation(x,mp):return sum(((x>>i)&1)<<dst for i,dst in enumerate(mp))
def expression0(x):
    return (((x&0x100)<<7)+((x&0x200)<<4)+((x&0x400)<<1)+((x>>2)&0x200)+((x>>4)&0x100)+((x>>3)&0x400)+((x&2)<<4)+((x&4)<<1)+((x&1)<<7)+((x>>2)&0x1000)+((x>>1)&0x4000)+((x>>2)&2)+((x>>4)&1)+((x>>3)&4)+((x>>2)&0x10)+((x>>1)&0x40))
def expression1(x):
    return ((x&0x100)+((x&0x200)<<1)+((x&0x400)<<2)+((x&0x800)<<3)+((x&0x1000)<<3)+(x&0x2000)+((x&0x10)<<3)+((x>>6)&0x200)+(x&1)+((x&2)<<1)+((x&4)<<2)+((x&8)<<3)+((x>>3)&0x800)+(x&0x20)+((x>>3)&8)+((x>>6)&2))
for ch,fn in enumerate([expression0,expression1]):
    assert sorted(maps[ch])==list(range(16))
    seen=set()
    for x in range(65536):
        y=fn(x);assert y==permutation(x,maps[ch]);seen.add(y)
    assert len(seen)==65536
bitrows=[{'input_bit':i,'output_bit_index0':maps[0][i],'output_bit_index1':maps[1][i]} for i in range(16)]
with (D/'response_bit_mapping.tsv').open('w',encoding='utf8',newline='') as fp:
    w=csv.DictWriter(fp,fieldnames=list(bitrows[0]),delimiter='\t');w.writeheader();w.writerows(bitrows)
rows=[];offset=0x684
for i in range(44):
    mode,reg,val,mask,shift,lo,hi,selector,otherlo,otherhi=struct.unpack_from('<IHHHHHHIHH',B,offset+i*24)
    assert mode in (0,1,2) and selector in (0,1) and mask and shift<16
    assert (val<<shift)&mask==val<<shift
    rows.append(dict(index=i,firmware_va=hex(0xba684+i*24),firmware_offset=hex(0xa84+i*24),mode=['set','add','subtract'][mode],register=hex(reg),value_or_delta=hex(val),mask=hex(mask),shift=shift,condition_source='A: reg[0x517] bits 11:5' if selector==0 else 'C: reg[0x506] bits 15:12 + reg[0x507] bits 3:0 << 4',condition_min=lo,condition_max=hi,B_reg_0x7d7_bits_4_0_min=otherlo,B_reg_0x7d7_bits_4_0_max=otherhi))
with (D/'conditional_register_rules.tsv').open('w',encoding='utf8',newline='') as fp:
    w=csv.DictWriter(fp,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
raw=B[offset:offset+44*24];assert raw==F[0xa84:0xea4]
(D/'conditional_register_table.bin').write_bytes(raw)
(D/'conditional_register_rules.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
disasm('PBUF',0xe8ff0,0xe90ec,'response_bit_permutation.txt')
disasm('PBUF',0xe74cc,0xe7850,'window_constructor_full.txt')
disasm('PBUF',0xe2db8,0xe2dc0,'context_bind_inner.txt')
disasm('PBUF',0xce8a8,0xce8cc,'context_bind_outer.txt')
disasm('PBUF',0xe1c78,0xe1d0a,'access_mode_sequence.txt')
disasm('PBUF',0xe8d58,0xe8dfa,'access_mode_sequence_low_level.txt')
disasm('PBUF',0xe8e04,0xe8e1a,'access_mode_close.txt')
disasm('PBUF',0xdbcee,0xdbdb4,'conditional_table_consumer.txt')
disasm('PBUF',0xdaa74,0xdab68,'training_result_collection.txt')
disasm('PBUF',0xe7d5a,0xe7e12,'narrow_register_read.txt')
disasm('PBUF',0xe8076,0xe8106,'narrow_register_write.txt')
disasm('PBUF',0xe7bf8,0xe7c2c,'status_poll.txt')
# Script bytes reconstructed from static shifts/masks; no target-code emulation.
def script_tokens(reg,data,op):
    word0=((reg&0x3ff)<<20)|(((reg>>10)&0xf)<<16)|(data&0xffff)
    word1=(op&0xf)<<4
    return [(word1>>3)&31,((word1&7)<<2)|((word0>>30)&3),(word0>>25)&31,(word0>>20)&31,(word0>>15)&31,(word0>>10)&31,(word0>>5)&31,word0&31]
assert script_tokens(0x7c8,0,9)==[18,0,30,8,2,0,0,0]
assert script_tokens(0x7c8,0x540,8)==[16,0,30,8,2,1,10,0]
J={'scope':'Offline static parsing, disassembly, constant/dataflow analysis and arithmetic checks of transcribed expressions only. No DLL/firmware execution, target emulation or hardware access.',
   'input_firmware_sha256':hashlib.sha256(F).hexdigest(),
   'mmio':{'evidence':'BL at 0xCF25E -> 0xE74CC; wrapper 0xD2C70 preserves input base, loop runs twice. Global binding 0xCE8BA -> 0xE2DB8 -> slot 0x91194; outer pointer stored at 0x913C4.',
           'control_base':'0x03800000','port_base0':'0x03810000','port_base1':'0x03820000','port_stride':'0x10000','hardware_block_names':'Unverified'},
   'response_bit_permutation':{'input_bit_to_output_bit':maps,'selector':'r1==0 uses first mapping; r1!=0 uses second','input_width':16,'unused_arguments':'r0/context and r2/second index not used by this function','validation':'All 65536 16-bit inputs for both branches: independently transcribed mask/shift expressions equal bit maps; each map is bijective. This does not execute original target code.'},
   'mode_sequence':{'function':'0xE1C78, also 0xE8D58','writes':[{'register':'0x3E8','value':hex(v)} for v in [0xcafe,0xca2e,0x1137,0x2ba0,0xdead]],'check':'register 0x3FE bit 15, at most ten read attempts','close':'0xE8E04 writes 0xBABA to register 0x3FC','interpretation':'Access-mode/unlock-like sequence; named purpose not proven'},
   'table':{'va':'0xBA684','pbuf_offset':'0x684','firmware_offset':'0xA84','dll_offset':'0xEAB54','entries':44,'entry_size':24,'sha256':hashlib.sha256(raw).hexdigest(),'consumer':'0xDBCEE','observed_gate':'Global state [0xB2104+0x30] == 0; caller also checks low byte of register 0x101 == 0 before entering access mode and applying table','conditions':'A=(read_alternate(0x517)>>5)&0x7F; B=read_alternate(0x7D7)&0x1F; C=((read_alternate(0x506)>>12)&0xF)|((read_alternate(0x507)&0xF)<<4). selector0 chooses A; selector1 chooses C. B supplies second range test. Hardware meanings unknown.'},
   'script_descriptor':{'read_helper':'0xE192C','write_helper':'0xE18C6','read_operation_nibble':9,'write_operation_nibble':8,'eight_token_formula':['2*op','0','(reg>>5)&31','reg&31','((reg>>10)&15)*2 + ((data>>15)&1)','(data>>10)&31','(data>>5)&31','data&31'],'controller_script_registers':'8 active 5-bit fields in byte lanes of base+0x24 and base+0x28; writer also fills base+0x2C (unused slots for 8-token form)','submit_type':'0xF in command low nibble; token count and mode fields also packed into base+0x1C','read_example_0x7c8':script_tokens(0x7c8,0,9),'write_example_0x7c8_data_0x540':script_tokens(0x7c8,0x540,8),'wire_protocol_status':'These are controller script fields; external physical signal semantics and opcode names are unverified.'},
   'training_caution':'0xDAA74 reads 0x102, but then initializes r10 to literal 0x55, producing four enabled pairs while collecting 0x108..0x10F. Do not equate the TRAINING_FAILED string with a recovered active timing sweep.'}
(D/'continued_findings.json').write_text(json.dumps(J,indent=2),encoding='utf8')
print(json.dumps({'MMIO':J['mmio'],'permutation_examples':[(ch,hex(expression0(0x55aa) if ch==0 else expression1(0x55aa))) for ch in [0,1]],'table_entries':len(rows),'table_sha256':J['table']['sha256'],'distinct_registers':len(set(x['register'] for x in rows)),'script_examples':J['script_descriptor']},indent=2))

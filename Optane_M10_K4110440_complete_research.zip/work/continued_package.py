import pathlib,json,hashlib,struct,zipfile
P=pathlib.Path(__file__).resolve().parent;O=P.parent/'outputs';D=O/'continued_analysis'
J=json.loads((D/'continued_findings.json').read_text());F=(O/'K4110440_005_signed_firmware.bin').read_bytes();B=(O/'firmware_PBUF.bin').read_bytes();T=(D/'conditional_register_table.bin').read_bytes()
assert hashlib.sha256(F).hexdigest()==J['input_firmware_sha256']
assert F[0x400:0x400+len(B)]==B
assert T==B[0x684:0xaa4]
assert hashlib.sha256(T).hexdigest()==J['table']['sha256']
rows=json.loads((D/'conditional_register_rules.json').read_text())
assert len(rows)==44 and len({r['register'] for r in rows})==32
for i,r in enumerate(rows):
    v=struct.unpack_from('<IHHHHHHIHH',T,i*24)
    assert int(r['register'],16)==v[1] and int(r['mask'],16)==v[3] and r['shift']==v[4]
    assert r['condition_min']==v[5] and r['condition_max']==v[6]
    assert r['B_reg_0x7d7_bits_4_0_min']==v[8] and r['B_reg_0x7d7_bits_4_0_max']==v[9]
    assert r['condition_source'].startswith('A:' if v[7]==0 else 'C:')
need={'mmio_constructor_call_context.txt':['cf252:','cf256:','cf25e:'], 'conditional_table_consumer.txt':['dbd2a:','dbd36:','dbd42:','dbdaa:'], 'narrow_register_read.txt':['e7d9c:','e7dc0:','e7dda:'], 'narrow_register_write.txt':['e80b0:','e80d8:','e80de:'], 'context_bind_inner.txt':['e2db8:','e2dbc:'], 'context_bind_outer.txt':['ce8ba:','ce8c6:']}
for name,markers in need.items():
    text=(D/name).read_text()
    for marker in markers:assert marker in text,(name,marker)
for src,dst in [('register_sweep.txt','extended_register_read.txt'),('array_constructor_helper.txt','no_op_construction_helper.txt')]:
    p=D/src
    if p.exists() and not (D/dst).exists():p.rename(D/dst)
files=[p for p in sorted(D.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt']
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files)
(D/'SHA256SUMS.txt').write_text(manifest,encoding='utf8')
z=O/'K4110440_round2_analysis_bundle.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zz:
    for p in files+[D/'SHA256SUMS.txt']:zz.write(p,p.name)
with zipfile.ZipFile(z) as zz:
    assert zz.testzip() is None
    for line in manifest.splitlines():
        digest,name=line.split('  ',1);assert hashlib.sha256(zz.read(name)).hexdigest()==digest
print(json.dumps({'verified':'Original payload identity, raw table boundaries, all 44 record fields/conditions, evidence instruction addresses, bundle CRCs/hashes; bit permutations and final register values verified by earlier expression checks','files':len(files)+1,'bundle_bytes':z.stat().st_size,'bundle_sha256':hashlib.sha256(z.read_bytes()).hexdigest()},indent=2))

import pathlib,struct,json,hashlib
from cryptography.hazmat.primitives.serialization import pkcs7
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
P=pathlib.Path(__file__).resolve().parent;O=P.parent/'outputs'
B=(P/'SB_K4110440_x64.dll').read_bytes();D=(O/'authenticode_0.p7b').read_bytes()
class Node:
    def __init__(self,o):
        self.o=o;self.tag=D[o];ll=D[o+1];p=o+2
        if ll&128:n=ll&127;ll=int.from_bytes(D[p:p+n],'big');p+=n
        self.p=p;self.end=p+ll;self.value=D[p:self.end];self.raw=D[o:self.end];self.children=[]
        if self.tag&32:
            while p<self.end:
                nn=Node(p);self.children.append(nn);p=nn.end
            assert p==self.end
def oid(n):
    v=n.value;a=[v[0]//40,v[0]%40];t=0
    for x in v[1:]:
        t=t*128+(x&127)
        if not x&128:a.append(t);t=0
    return '.'.join(map(str,a))
sd=Node(0).children[1].children[0];ci=sd.children[2];content=ci.children[1].children[0]
claimed=content.children[1].children[1].value
pe=struct.unpack_from('<I',B,0x3c)[0];opt=pe+24;cs=opt+64;dd=opt+112;sect=opt+struct.unpack_from('<H',B,pe+20)[0];nr=struct.unpack_from('<H',B,pe+6)[0];head=struct.unpack_from('<I',B,opt+60)[0]
certoff,certlen=struct.unpack_from('<II',B,dd+4*8)
h=hashlib.sha256();h.update(B[:cs]);h.update(B[cs+4:dd+32]);h.update(B[dd+40:head]);sec=[]
for i in range(nr):
    sz,off=struct.unpack_from('<II',B,sect+40*i+16);sec.append((off,sz))
for off,sz in sorted(sec):h.update(B[off:off+sz])
sumlen=head+sum(sz for off,sz in sec)
if sumlen<len(B)-certlen:h.update(B[sumlen:len(B)-certlen])
R={'authenticode_image_digest':h.hexdigest(),'embedded_image_digest':claimed.hex(),'image_digest_matches':h.digest()==claimed,'offline_scope':'Cryptographic content consistency only. No trust-store validation, root trust, certificate chain validation, revocation lookup, online checks, or device acceptance tests.'}
certs=pkcs7.load_der_pkcs7_certificates(D)
si=sd.children[-1].children[0]
def attrs(n):return {oid(x.children[0]):x.children[1].children[0] for x in n.children}
def verify(si,content_data,alg):
    ser=int.from_bytes(si.children[1].children[1].value,'big');cer=next(c for c in certs if c.serial_number==ser)
    at=si.children[3];ar=attrs(at);md=ar['1.2.840.113549.1.9.4'].value
    rr={'subject':cer.subject.rfc4514_string(),'serial':hex(ser),'digest_matches':hashlib.new(alg,content_data).digest()==md,'message_digest':md.hex()}
    der=b'\x31'+at.raw[1:]
    try:cer.public_key().verify(si.children[5].value,der,padding.PKCS1v15(),hashes.SHA256() if alg=='sha256' else hashes.SHA1());rr['rsa_signature_valid']=True
    except Exception as ex:rr['rsa_signature_valid']=False;rr['error']=str(ex)
    if '1.2.840.113549.1.9.5' in ar:rr['signing_time_raw']=ar['1.2.840.113549.1.9.5'].value.decode()
    return rr
R['main_signer']=verify(si,content.value,'sha256')
R['content_digest_with_tag_matches']=hashlib.sha256(content.raw).digest()==attrs(si.children[3])['1.2.840.113549.1.9.4'].value
if len(si.children)>6:
    ua=attrs(si.children[6]);counter=ua.get('1.2.840.113549.1.9.6')
    if counter:R['counter_signer']=verify(counter,si.children[5].value,'sha1')
(O/'signature_verification.json').write_text(json.dumps(R,indent=2),encoding='utf8');print(json.dumps(R,indent=2))

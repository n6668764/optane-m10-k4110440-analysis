import pathlib,hashlib,json,zipfile,re,struct
P=pathlib.Path(__file__).resolve().parent;O=P.parent/'outputs'
B=(P/'SB_K4110440_x64.dll').read_bytes();F=(O/'K4110440_005_signed_firmware.bin').read_bytes()
A=json.loads((O/'analysis.json').read_text(encoding='utf8'));R=json.loads((O/'firmware_analysis.json').read_text());S=json.loads((O/'signature_verification.json').read_text())
assert hashlib.sha256(B).hexdigest()==A['hashes']['sha256']
assert F==B[0xea0d0:0x1790d0]
assert hashlib.sha256(F).hexdigest()==R['sha256']
assert R['inner_header']['revision']=='K4110440-005'
for x in R['segments']:
    o=int(x['firmware_offset'],16);part=(O/x['file']).read_bytes()
    assert part==F[o:o+x['length']]
    assert hashlib.sha256(part).hexdigest()==x['sha256']
assert S['image_digest_matches'] and S['main_signer']['digest_matches'] and S['main_signer']['rsa_signature_valid']
assert S['counter_signer']['digest_matches'] and S['counter_signer']['rsa_signature_valid']
assert R['rsa']['verified_coverage']=='manifest_prefix_plus_all_after_signature'
for off,t in [(0x20aa8,b'*ID_BAD_MEDIA_PLL'),(0x20abc,b'*MISSING_DQS'),(0x21090,b'*TRAINING_FAILED')]:assert F[off:off+len(t)]==t
assert B[0xc10e8:0xc10e8+len(b'K4110440_005_dell_client_signed')]==b'K4110440_005_dell_client_signed'
assert len(F[0x8ee08:])==504 and set(F[0x8ee08:])=={255}
assert len(A['resources'])==1 and A['resources'][0]['type']=='MANIFEST'
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(O.iterdir()) if p.is_file() and p.name not in ['SHA256SUMS.txt','SB_K4110440_analysis_bundle.zip'])
(O/'SHA256SUMS.txt').write_text(manifest,encoding='utf8')
z=O/'SB_K4110440_analysis_bundle.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zz:
    for p in sorted(O.iterdir()):
        if p.is_file() and p!=z:zz.write(p,p.name)
with zipfile.ZipFile(z) as zz:
    assert zz.testzip() is None
    for line in manifest.splitlines():
        h,name=line.split('  ',1);assert hashlib.sha256(zz.read(name)).hexdigest()==h
print(json.dumps({'verified':'DLL/image hashes, exact extraction, all segment boundaries/hashes, named evidence offsets, revision, both signature layers, manifest, ZIP CRC and content hashes','bundle_size':z.stat().st_size,'bundle_sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'file_count':len(list(O.iterdir())),'report_file':'SB_K4110440_static_analysis.md'},indent=2))

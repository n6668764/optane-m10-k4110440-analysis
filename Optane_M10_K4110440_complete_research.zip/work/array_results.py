import pathlib,json,struct,hashlib,csv,zipfile
from continue_static import disasm
P=pathlib.Path(__file__).resolve().parent;O=P.parent/'outputs';D=O/'array_analysis'
B=(O/'firmware_PBUF.bin').read_bytes();V=(O/'firmware_VBUF.bin').read_bytes();F=(O/'K4110440_005_signed_firmware.bin').read_bytes()
def pack_address(a):return ((a&15)|((a>>4)<<5))&0xffffffff
def unpack_address(a):return (a&15)|((a>>5)<<4)
for a in list(range(65536))+[0x1234567,0x3fffffff,0x40000000,0x7fffffff,0x80000000,0xffffffff]:
    p=pack_address(a);assert not p&16;assert unpack_address(p)==(a&0x7fffffff)
def pack_command(old,opcode,portflag,target,A,B,follow):
    mask=0xf|0x7c0|0x70000|0x10000000
    field=(B&3)|((follow&1)<<2)|((A&3)<<3)
    return ((old&~mask)|(opcode&15)|(field<<6)|((target&7)<<16)|((portflag&1)<<28)|0x80000000)&0xffffffff
for target in range(8):
    for A in range(4):
        for Bv in range(4):
            for f in range(2):
                c=pack_command(0,2,0,target,A,Bv,f)
                assert (c&15)==2 and (c>>16)&7==target and (c>>6)&3==Bv and (c>>8)&1==f and (c>>9)&3==A
def diagnostic_address(w1,w2):return ((w1&0x3ffffff)<<4)|(w1>>30)|((w2&3)<<2)
assert diagnostic_address(0x12345678,2)==0x23456788
record={
 'scope':'Offline static analysis. No DLL/firmware execution, target emulation, hardware access or updater run. Numeric checks evaluate independently transcribed expressions only.',
 'firmware_sha256':hashlib.sha256(F).hexdigest(),
 'conclusion':'High-confidence candidate raw-media 16-byte data read/write path. Its dataflow is distinguished from the 16-bit register-access path. Exact 3D XPoint wire protocol, cell coordinates, persistence/ECC policy and AHU14132 identity remain unverified.',
 'bases':['0x03810000','0x03820000'],
 'read_chain':['0xE2B14','0xE2DC0','0xE7AFC','0xE7942'],
 'write_chain':['0xE2C10','0xE2DD6','0xE7A1C','0xE7942'],
 'alternate_write_chain':['0xE2C40','0xE2DF6','0xE7AB2','0xE7942'],
 'mapped_wrappers':{'read':'0xC6912','write':'0xC695A','read_modify_write':'0xC69A0','selector_table':'0x86838','selector_encoding':'port=(entry>>5)&7; target=entry&31. Lower layer asserts port<2 and target<8. Table is built from accepted targets at 0xDA30A.'},
 'data_size_bytes':16,
 'mmio_fields':[
  {'offset':'0x08','role':'Status bit 0 inspected before submission and during poll; old value written back before preflight. Write-back semantics unknown.'},
  {'offset':'0x1C','role':'Command register. Raw-data read op=0x0, write op=0x2; selected follow-up op=0xB.'},
  {'offset':'0x20','role':'Encoded media-side address argument; not the selector<<16 packing used for simple register access.'},
  {'offset':'0x30..0x3C','role':'Four 32-bit read-result words, copied directly to output buffer without 0xE8FF0 bit permutation.'},
  {'offset':'0x40..0x4C','role':'Four 32-bit source-data words, filled by 0xE7942 for opcodes 1,2,0xE when a non-null source pointer is supplied.'},
  {'offset':'0x78','role':'Per-target two-bit preflight state: (value>>(2*target))&3. States 1 or 2 trigger assertion unless op=3; physical state names unknown.'}
 ],
 'command_fields':{'bits_3_0':'opcode','bits_7_6':'B&3','bit_8':'follow_or_flag&1','bits_10_9':'A&3','bits_18_16':'target&7','bit_28':'ctx per-port flag&1','bit_31':'set on submission','other_bits':'preserved from old command word','read_parameters':'A=caller read parameter; B=0 and flag=0','write_parameters':'A/B are caller-supplied parameters; flag also selects optional later 0xB phase in 0xE7A1C. Formal hardware meanings unknown.'},
 'address_encoding':{'formula':'((address & 0xF) | ((address >> 4) << 5)) modulo 2^32','inserted_zero_bit':4,'source_bit_31':'Not represented after 32-bit truncation; no address range check was identified within this setter. Caller bounds may constrain it.','unit':'Loops increment this address by 1 while advancing the data buffer by 16 bytes; this is evidence for the software transfer index, not proof of the minimum physical cell/line size.'},
 'completion':{'function':'0xE7BF8','status':'base+0x08 bit 0','requirement':'Ten consecutive set observations; an unset observation resets the consecutive-set counter and increments a separate cumulative-unset counter','limit_for_this_path':'0x6ACFC0 cumulative unset observations; this is not the total poll count','units':'Observation count; wall-clock units not established','limitation':'Completion check alone does not establish ECC integrity or nonvolatile persistence.'},
 'followup':{'function':'0xE7A6E','opcode':'0xB','behavior':'Loops over port indices 0 and 1 and submits the same address/target with 0xB; polling uses the original caller port. Purpose not assigned as commit/program/flush without more evidence.'},
 'proofs':[
  {'function':'0xE7AFC','instructions':['0xE7B2C calls submit with op 0','0xE7B38 polls','0xE7B4E reads base+0x30+i*4','0xE7B54 stores to buffer+i*4','0xE7B52 bounds i<4']},
  {'function':'0xE7942','instructions':['0xE79A0 recognizes op 2','0xE79BC loads four source words','0xE79C4 stores base+0x40+i*4','0xE7A10 writes encoded address','0xE7A16 writes command']},
  {'function':'0xE087E','instructions':['Writes patterns 0x55AA55AA and 0xAA55AA55','0xE093A calls alternate data write','0xE097C calls data read','0xE0984..0xE09BE compares all four words and accumulates set/clear differences']},
  {'function':'0xC69A0','instructions':['0xC69C0 reads a 16-byte buffer','0xC69DE..0xC69E4 XOR selected bytes with 0xFF','0xC69F4 writes the modified buffer back at the same address']},
  {'function':'0x40C8A8','instructions':['read/write branches use the same target lookup and address','0x40C95A advances pointer by 0x10','0x40C95C advances transfer index by 1','0x40C8D4/0x40C8E8 derive per-target address quotient and target-slot remainder']}
 ],
 'internal_diagnostic_dispatch':{'entry':'0x40C1EE','formal_arguments':'r0=record pointer, r1=port, r2=target','selector_9':'Calls data write 0xE2C10','selector_10':'Calls data read 0xE2B14','selector_11':'Calls alternate data write 0xE2C40','data_record_offset':'0x0C, length 16 bytes','record_address_formula':'((word_at_0x04 & 0x03FFFFFF)<<4) | (word_at_0x04>>30) | ((word_at_0x08&3)<<2)','transport_status':'These are internal dispatch selectors, not established NVMe opcodes or a sendable host-command schema.'},
 'limits':['AHU14132 identification unverified','External row/column/bank bit definitions unverified','CPU path moves 16 bytes; physical array granularity unverified','ECC/metadata and persistence conditions not fully reconstructed','Production NVMe/LBA mapping and bulk DMA pipeline not fully linked','0xB follow-up operation semantics unverified']
}
(D/'raw_media_findings.json').write_text(json.dumps(record,indent=2),encoding='utf8')
rs=[('PBUF',0xe2b14,0xe2b30,'data_read_wrapper'),('PBUF',0xe2c10,0xe2c66,'data_write_wrappers'),('PBUF',0xe2dc0,0xe2e16,'data_adapter_layer'),('PBUF',0xe7942,0xe7a1c,'raw_data_submit'),('PBUF',0xe7a1c,0xe7afc,'data_write_and_followup'),('PBUF',0xe7afc,0xe7b5c,'data_read_four_words'),('PBUF',0xe7bf8,0xe7c2c,'data_completion_poll'),('PBUF',0xc6912,0xc69fe,'mapped_read_write_modify'),('PBUF',0xe087e,0xe09e2,'pattern_write_read_compare'),('VBUF',0x40c8a8,0x40c96e,'striped_16byte_loop'),('VBUF',0x40c1ee,0x40c268,'internal_dispatch_decode'),('VBUF',0x40c312,0x40c3ac,'internal_data_dispatch'),('PBUF',0xe927a,0xe928f,'per_target_preflight'),('PBUF',0xda30a,0xda36a,'accepted_target_map_builder'),('PBUF',0xe15a4,0xe15f8,'data_status_followup')]
for seg,a,z,name in rs:(D/(name+'.txt')).write_text(disasm(seg,a,z),encoding='utf8')
with (D/'data_register_fields.tsv').open('w',encoding='utf8',newline='') as fp:
    w=csv.DictWriter(fp,fieldnames=['offset','role'],delimiter='\t');w.writeheader();w.writerows(record['mmio_fields'])
print(json.dumps({'read_chain':record['read_chain'],'write_chain':record['write_chain'],'data_bytes':16,'address_examples':[(hex(a),hex(pack_address(a))) for a in [0,0xf,0x10,0x1234567,0x7fffffff]],'example_read_command_old0_port0_target3_A1':hex(pack_command(0,0,0,3,1,0,0)),'example_write_command_old0_port0_target3_A1_B0_flag0':hex(pack_command(0,2,0,3,1,0,0)),'status':'Static expressions and evidence prepared; examples are not hardware-tested instructions'},indent=2))

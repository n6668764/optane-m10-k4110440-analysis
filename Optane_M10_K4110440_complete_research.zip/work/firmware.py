import pathlib,struct,hashlib,json,collections,math,re,zlib,lzma
from cryptography.hazmat.primitives.asymmetric import rsa,padding
from cryptography.hazmat.primitives import hashes,serialization
P=pathlib.Path(__file__).resolve().parent; O=P.parent/'outputs'
B=(P/'SB_K4110440_x64.dll').read_bytes();a=0xea0d0;n=0x8f000;F=B[a:a+n]
assert len(F)==n
def H(b):return hashlib.sha256(b).hexdigest()
def E(b):return -sum(x/len(b)*math.log2(x/len(b)) for x in collections.Counter(b).values()) if b else 0
def u(o):return struct.unpack_from('<I',F,o)[0]
(O/'K4110440_005_signed_firmware.bin').write_bytes(F)
R={'dll_offset':hex(a),'dll_rva':'0xec0d0','size':n,'size_hex':hex(n),'sha256':H(F),'entropy':E(F),'boundary_evidence':['GetTargetFirmwareBinary RVA 0xA2A6 loads 0x8F000','RVA 0xA2B0 loads VA 0x1800EC0D0 -> file offset 0xEA0D0','Outer dword at +0x18 = 0x23C00; times 4 = 0x8F000','Immediately after blob at DLL offset 0x1790D0 is host C++ RTTI; final blob bytes are 0xFF padding'], 'manifest_words':{hex(i):hex(u(i)) for i in range(0,0x80,4)}}
R['inner_header']={'magic':'EFLI','offset':hex(0x284),'declared_size':hex(u(0x288)),'word_0x28c':hex(u(0x28c)),'segment_count':u(0x290),'word_0x294':hex(u(0x294)),'revision':F[0x298:0x2a3].decode(),'segment_source_base_inferred':'0x400','size_interpretation':'0x8EB80 + magic length 4 + offset 0x284 = 0x8EE08, followed by 504 bytes of 0xFF padding; semantic interpretation inferred'}
# Revision is a 12-character fixed field, not a null-terminated string.
R['inner_header']['revision']=F[0x298:0x2a3].decode()+chr(F[0x2a3])
segments=[]
for i in range(5):
    p=0x300+16*i;tag=F[p:p+4].decode();rel,sz,load=struct.unpack_from('<III',F,p+4);start=0x400+rel;data=F[start:start+sz];assert len(data)==sz
    fn=f'firmware_{tag}.bin';(O/fn).write_bytes(data)
    segments.append(dict(tag=tag,table_offset=hex(p),source_relative=hex(rel),firmware_offset=hex(start),dll_offset=hex(a+start),length=sz,length_hex=hex(sz),load_address_candidate=hex(load),entropy=E(data),sha256=H(data),file=fn,first32=data[:32].hex(' ')))
R['segments']=segments
R['firmware_strings']=[]
for m in re.finditer(rb'[\x20-\x7e]{4,}',F):
    s=m.group().decode();R['firmware_strings'].append(dict(fw_offset=m.start(),dll_offset=a+m.start(),text=s))
(O/'firmware_strings.tsv').write_text('firmware_offset\tdll_offset\ttext\n'+'\n'.join(f"0x{s['fw_offset']:06X}\t0x{s['dll_offset']:08X}\t{s['text']}" for s in R['firmware_strings']),encoding='utf8')
R['exact_searches']={}
for term in ['AHU14132','AHU','14132','3D XPoint','XPoint','Silicon Motion','SM2263','PHY','phy','PLL','TRAINING','StonyBeach']:
    R['exact_searches'][term]={'ascii_offsets':[hex(m.start()) for m in re.finditer(re.escape(term.encode()),F)],'utf16_offsets':[hex(m.start()) for m in re.finditer(re.escape(term.encode('utf-16le')),F)]}
# Check possible embedded RSA block without executing any target code.
mod=F[0x80:0x180];e=u(0x180);sig=F[0x184:0x284]
R['rsa']={'modulus_offset':'0x80','modulus_length':256,'exponent_offset':'0x180','exponent':e,'signature_offset':'0x184','signature_length':256,'attempts':[]}
recovered=[]
for endian in ['little','big']:
    nn=int.from_bytes(mod,endian)
    for se in ['little','big']:
        ss=int.from_bytes(sig,se);out=pow(ss,e,nn).to_bytes(256,'big');fn=f'work_rsa_{endian}_{se}.txt';(P/fn).write_text(out.hex())
        if out[:2]==b'\x00\x01':
            recovered.append((endian,se,out));R['rsa']['attempts'].append({'modulus_endian':endian,'signature_endian':se,'pkcs1_block':out.hex()})
if recovered:
    endian,se,em=recovered[0];key=rsa.RSAPublicNumbers(e,int.from_bytes(mod,endian)).public_key();(O/'firmware_embedded_rsa_public_key.pem').write_bytes(key.public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))
    delim=em.find(b'\0',2);di=em[delim+1:];R['rsa']['digest_info_hex']=di.hex();digest=di[-32:]
    candidates={'manifest_prefix_plus_all_after_signature':F[:0x80]+F[0x284:],'manifest_prefix_plus_EFLI_through_trailer':F[:0x80]+F[0x284:0x8ee08],'all_after_signature':F[0x284:],'EFLI_through_trailer':F[0x284:0x8ee08],'segments_plus_trailer':F[0x400:0x8ee08],'segments_only':F[0x400:0x8ee00],'manifest_prefix':F[:0x80]}
    R['rsa']['digest_comparisons']={k:{'sha256':H(v),'matches':hashlib.sha256(v).digest()==digest} for k,v in candidates.items()}
    for k,v in candidates.items():
        if hashlib.sha256(v).digest()==digest:
            try:key.verify(int.from_bytes(sig,se).to_bytes(256,'big'),v,padding.PKCS1v15(),hashes.SHA256());R['rsa']['verified_coverage']=k
            except Exception as ex:R['rsa']['verification_error']=str(ex)
# Entropy and container probe: common zlib headers, and structurally plausible LZMA-alone candidates.
R['compression_probes']={'zlib':[],'lzma_alone':[]}
for i in range(len(F)-2):
    if F[i]==0x78 and F[i+1] in (1,0x5e,0x9c,0xda):
        try:
            d=zlib.decompressobj();out=d.decompress(F[i:],16*1024*1024)
            if d.eof:R['compression_probes']['zlib'].append({'offset':hex(i),'decoded_length':len(out),'sha256':H(out)})
        except zlib.error:pass
for i in range(0,len(F)-13):
    if F[i]!=0x5d:continue
    ds=int.from_bytes(F[i+1:i+5],'little');size=int.from_bytes(F[i+5:i+13],'little')
    if ds not in [2**j for j in range(12,25)] or not (size==2**64-1 or 0<size<16*1024*1024):continue
    try:
        d=lzma.LZMADecompressor(format=lzma.FORMAT_ALONE,memlimit=64*1024*1024);out=d.decompress(F[i:],max_length=16*1024*1024)
        if d.eof:R['compression_probes']['lzma_alone'].append({'offset':hex(i),'decoded_length':len(out),'sha256':H(out)})
    except lzma.LZMAError:pass
R['crc_candidates']={'trailer_hex':F[0x8ee00:0x8ee08].hex(),'crc32_segments':hex(zlib.crc32(F[0x400:0x8ee00])),'crc32_efli_without_trailer':hex(zlib.crc32(F[0x284:0x8ee00])),'crc32_efli_except_last_word':hex(zlib.crc32(F[0x284:0x8ee04]))}
# Produce inert ELF32 wrappers for static disassembly. Segment contents remain unchanged.
for s in segments[:2]:
    data=(O/s['file']).read_bytes();addr=int(s['load_address_candidate'],16)
    strings=b'\0.text\0.shstrtab\0';dataoff=0x100;stroff=dataoff+len(data);shoff=(stroff+len(strings)+3)&~3
    hdr=b'\x7fELF'+bytes([1,1,1,0])+bytes(8)+struct.pack('<HHIIIIIHHHHHH',2,40,1,addr,0,shoff,0x5000000,52,0,0,40,3,2)
    out=hdr.ljust(dataoff,b'\0')+data+strings;out=out.ljust(shoff,b'\0')
    out+=bytes(40)+struct.pack('<IIIIIIIIII',1,1,6,addr,dataoff,len(data),0,0,4,0)+struct.pack('<IIIIIIIIII',7,3,0,0,stroff,len(strings),0,0,1,0)
    (P/f'{s["tag"]}_arm_static.elf').write_bytes(out)
(O/'firmware_analysis.json').write_text(json.dumps(R,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in R.items() if k!='firmware_strings'},indent=2))

import csv, hashlib, json, struct, zipfile
from array_results import rs, P, O, D, F, B, V
from continue_static import disasm, CALLS

def sha(b):
    return hashlib.sha256(b).hexdigest()

dll = (P/'SB_K4110440_x64.dll').read_bytes()
assert sha(dll) == '254e2b87f2f85435dc83798b634345a402a2212d8e64bb80bbe85cf6a0b68857'
assert sha(F) == '0a42b2e10bd725f3eecdbdbf52fd4fc4c7581887a5fe94c0cecb3561f600a7ee'
assert dll[0xea0d0:0x1790d0] == F
assert F[0x400:0x400+len(B)] == B
assert F[0x3bc00:0x3bc00+len(V)] == V

extra = [
    ('PBUF',0xcf236,0xcf262,'window_constructor_arguments'),
    ('PBUF',0xe74cc,0xe7530,'window_constructor_and_global'),
    ('PBUF',0xd2c20,0xd2c9a,'window_base_preservation'),
    ('PBUF',0xe2db8,0xe2dc0,'context_binding'),
    ('PBUF',0xce8a8,0xce8cc,'wrapper_global_binding'),
]
for seg,a,z,name in extra:
    (D/(name+'.txt')).write_text(disasm(seg,a,z),encoding='utf8')

literals = {0xe7850:0x91194,0xe2e18:0x91194,0xe2bc0:0x913c4,0xe2c98:0x913c4,0xe7cb8:0x6acfc0}
for va,expected in literals.items():
    assert struct.unpack_from('<I', B, va-0xba000)[0] == expected
literal_record = {hex(va):hex(value) for va,value in literals.items()}
(D/'verified_literals.json').write_text(json.dumps(literal_record,indent=2),encoding='utf8')

expected_calls = [
    ('PBUF',0xe2b28,0xe2dc0),('PBUF',0xe2dce,0xe7afc),
    ('PBUF',0xe2c2e,0xe2dd6),('PBUF',0xe2dee,0xe7a1c),
    ('PBUF',0xe2c5e,0xe2df6),('PBUF',0xe7a3e,0xe7942),
    ('PBUF',0xe7ad2,0xe7942),('PBUF',0xe7b2c,0xe7942),
    ('PBUF',0xe7a66,0xe7a6e),('PBUF',0xe7af4,0xe7a6e),
    ('PBUF',0xe093a,0xe2c40),('PBUF',0xe097c,0xe2b14),
    ('PBUF',0xc69c0,0xc6912),('PBUF',0xc69f4,0xc695a),
    ('VBUF',0x40c344,0xe2c10),('VBUF',0x40c36e,0xe2b14),
    ('VBUF',0x40c3a6,0xe2c40),
]
actual = {(x['segment'],x['address'],x['target']) for x in CALLS}
assert all(item in actual for item in expected_calls)

rawdir = D/'evidence_bytes'
rawdir.mkdir(exist_ok=True)
rows=[]
members=[D/'K4110440_cell_data_path_analysis.md',D/'raw_media_findings.json',D/'data_register_fields.tsv',D/'verified_literals.json']
for seg,a,z,name in rs+extra:
    segbase,fwoff,dlloff,data = (0xba000,0x400,0xea4d0,B) if seg=='PBUF' else (0x400000,0x3bc00,0x125cd0,V)
    offset=a-segbase
    chunk=data[offset:offset+(z-a)]
    assert len(chunk)==z-a
    assert chunk==F[fwoff+offset:fwoff+offset+len(chunk)]
    assert chunk==dll[dlloff+offset:dlloff+offset+len(chunk)]
    rawpath=rawdir/(name+'.bin')
    rawpath.write_bytes(chunk)
    members.extend([D/(name+'.txt'),rawpath])
    rows.append(dict(name=name,segment=seg,start_va=hex(a),stop_va_exclusive=hex(z),segment_offset=hex(offset),firmware_offset=hex(fwoff+offset),dll_offset=hex(dlloff+offset),length=len(chunk),sha256=sha(chunk)))
table=D/'evidence_locations.tsv'
with table.open('w',encoding='utf8',newline='') as fp:
    writer=csv.DictWriter(fp,fieldnames=list(rows[0]),delimiter='\t')
    writer.writeheader();writer.writerows(rows)
members.append(table)
verification = dict(
    scope='Offline file parsing, disassembly and independently transcribed arithmetic checks only. No target execution or hardware access.',
    verified_dll_sha256=sha(dll),verified_firmware_sha256=sha(F),
    firmware_equals_original_dll_slice=True,
    pbuf_and_vbuf_equal_original_firmware_slices=True,
    evidence_slice_count=len(rows),all_slices_equal_original_dll_and_firmware=True,
    verified_key_direct_thumb_calls=len(expected_calls),
    verified_literal_values=literal_record,
    completion_correction='Only unset observations increment the timeout counter; set observations increment the consecutive-success counter.',
    mathematical_checks='Address packing: 65536 low values plus selected boundaries. Command field combinations: all target/A/B/flag values in their encoded domains. No device behavior tested.'
)
vp=D/'verification.json'
vp.write_text(json.dumps(verification,indent=2),encoding='utf8');members.append(vp)
manifest=D/'SHA256SUMS.txt'
manifest.write_text(''.join(f'{sha(p.read_bytes())}  {p.relative_to(D).as_posix()}\n' for p in sorted(members)),encoding='utf8')
members.append(manifest)
archive=O/'K4110440_cell_data_path_evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in members:z.write(p,p.relative_to(D).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in members:assert z.read(p.relative_to(D).as_posix())==p.read_bytes()
print(json.dumps({'report':str(members[0]),'archive':str(archive),'members':len(members),'slice_count':len(rows),'archive_sha256':sha(archive.read_bytes()),'verified':True},indent=2))

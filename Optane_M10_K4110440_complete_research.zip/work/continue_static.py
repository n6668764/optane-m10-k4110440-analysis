import pathlib,struct,json,subprocess
P=pathlib.Path(__file__).resolve().parent;O=P.parent/'outputs';D=O/'continued_analysis';D.mkdir(exist_ok=True)
TOOL=r'C:\Program Files\MATLAB\R2024b\toolbox\sldrt\clang\win64\llvm-objdump.exe'
segments=[('PBUF',0xba000),('VBUF',0x400000)]
def scan_calls():
    result=[]
    for name,base in segments:
        b=(O/f'firmware_{name}.bin').read_bytes()
        for i in range(0,len(b)-3,2):
            h1,h2=struct.unpack_from('<HH',b,i)
            if h1&0xf800!=0xf000 or h2&0xd000!=0xd000:continue
            s=(h1>>10)&1;j1=(h2>>13)&1;j2=(h2>>11)&1;i1=1^(j1^s);i2=1^(j2^s)
            rel=(s<<24)|(i1<<23)|(i2<<22)|((h1&0x3ff)<<12)|((h2&0x7ff)<<1)
            if s:rel-=1<<25
            target=base+i+4+rel
            result.append(dict(segment=name,address=base+i,target=target,bytes=b[i:i+4].hex()))
    return result
CALLS=scan_calls();(P/'thumb_call_candidates.json').write_text(json.dumps(CALLS,indent=2))
def disasm(name,start,end,outfile=None):
    cmd=[TOOL,'-d','--triple=thumbv7-none-eabi','--mattr=+hwdiv,+hwdiv-arm',f'--start-address={start:#x}',f'--stop-address={end:#x}',str(P/f'{name}_arm_static.elf')]
    text=subprocess.run(cmd,capture_output=True,text=True,check=True).stdout
    if outfile:(D/outfile).write_text(text,encoding='utf8')
    return text
if __name__=='__main__':
    for target in [0xe74cc,0xe8ff0,0xda3da,0xe2b48,0xe2b60,0xe7d5a,0xe8076]:
        hits=[x for x in CALLS if x['target']==target]
        print('CALLERS',hex(target),[(x['segment'],hex(x['address'])) for x in hits])
        if target==0xe74cc:
            for x in hits:print(disasm(x['segment'],x['address']-64,x['address']+24,f'constructor_caller_{x["address"]:x}.txt'))
    for va in [0xe7850,0xe7854,0xe7858,0xe785c,0xe7860,0xe7864,0xe8070,0xe8348]:
        b=(O/'firmware_PBUF.bin').read_bytes();v=struct.unpack_from('<I',b,va-0xba000)[0];print('LITERAL',hex(va),hex(v))
